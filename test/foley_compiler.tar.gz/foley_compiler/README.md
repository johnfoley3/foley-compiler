foley-compiler
==============

Compiler for CS420

Steps to run:

Simply type 
	make
in the directory where the Makefile is located, along with all of the source files.

Then run ./main -inputfile- to see the lexical analysis results.
